# avondemh - CS 488 F 2024 - A2

## Compilation

program is compiled normally with `make` and `./A2`

## Manual

### Assumptions

- near plane is clamped to 0.01
- scaling is also clamped at 0.001 to avoid having to revert it

### Additions

- left shift works as middle button